import React from "react";
import BoardComment from "./BoardComment";

const BoardCommentWrapper = (props) => {
  return <BoardComment {...props}></BoardComment>;
};

export default BoardCommentWrapper;
