module.exports = {
  servers: [
    
  ],
  galleryUploadTempPath: './temp'
}